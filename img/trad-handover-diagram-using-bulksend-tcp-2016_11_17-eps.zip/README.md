## Description

### Client application
TCP BulkSendApplication


The link bandwidth between the switch1 and switch2 is 100Mbps.
The link bandwidth between each AP and switch1 is respectively 30Mbps


### experiment time
10PM on 2016-11-17
