## Description

### Client application
TCP OnOffApplication


The link bandwidth between the switch1 and switch2 is 100Mbps.
The link bandwidth between each AP and switch1 is respectively 30Mbps

We can clearly see that throughput of the moving station 
drops after it handover from AP3(about 86Kbps) to AP2(38Kbps).

### experiment time
9PM on 2016-11-17
